package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strings"

	libraryv1 "ebusta/api/proto/v1"
	"ebusta/internal/config"

	"google.golang.org/grpc"
)

type storageServer struct {
	libraryv1.UnimplementedStorageServiceServer
	osBaseURL string
	indexName string
	debug     bool
}

func flattenPositiveTerms(q *libraryv1.SearchQuery, neg bool, out *[]string) {
	if q == nil {
		return
	}

	if f := q.GetFilter(); f != nil {
		if !neg {
			v := strings.TrimSpace(f.GetValue())
			if v != "" {
				*out = append(*out, v)
			}
		}
		return
	}

	if l := q.GetLogical(); l != nil {
		childNeg := neg
		if l.GetOp() == 3 { // NOT toggles negation for its children
			childNeg = !neg
		}
		for _, n := range l.GetNodes() {
			flattenPositiveTerms(n, childNeg, out)
		}
	}
}

func findFirstFieldValue(q *libraryv1.SearchQuery, field string) (string, bool) {
	var found string

	var walk func(*libraryv1.SearchQuery, bool)
	walk = func(n *libraryv1.SearchQuery, neg bool) {
		if n == nil || found != "" {
			return
		}

		if f := n.GetFilter(); f != nil {
			if !neg && strings.EqualFold(strings.TrimSpace(f.GetField()), field) {
				v := strings.TrimSpace(f.GetValue())
				if v != "" {
					found = v
				}
			}
			return
		}

		if l := n.GetLogical(); l != nil {
			childNeg := neg
			if l.GetOp() == 3 {
				childNeg = !neg
			}
			for _, c := range l.GetNodes() {
				walk(c, childNeg)
			}
		}
	}

	walk(q, false)
	if found == "" {
		return "", false
	}
	return found, true
}

func suggestTemplate(ast *libraryv1.SearchQuery) string {
	if ast == nil {
		return "fl_mixed_search"
	}
	if f := ast.GetFilter(); f != nil {
		if strings.EqualFold(strings.TrimSpace(f.GetField()), "author") {
			return "fl_author_exact"
		}
		return "fl_mixed_search"
	}
	// For complex logical AST: we currently degrade to mixed_search (terms flattening).
	return "fl_mixed_search"
}

func buildTemplateRequest(req *libraryv1.SearchRequest) (string, map[string]interface{}, error) {
	ast := req.GetAst()
	if ast == nil {
		return "", nil, fmt.Errorf("missing ast; orchestrator must set SearchRequest.ast")
	}

	templateID := strings.TrimSpace(req.GetTemplateId())
	if templateID == "" {
		templateID = suggestTemplate(ast)
	}

	limit := req.GetLimit()
	if limit <= 0 {
		limit = 10
	}
	offset := req.GetOffset()
	if offset < 0 {
		offset = 0
	}

	params := map[string]interface{}{
		"from": offset,
		"size": limit,
	}

	// Template param name mapping (matches scripts/sync_templates.sh)
	paramName := "query"
	if templateID == "fl_author_exact" {
		paramName = "author"
	}

	var value string

	if paramName == "author" {
		if v, ok := findFirstFieldValue(ast, "author"); ok {
			value = v
		} else {
			// degrade: no explicit author node found, use flattened terms
			terms := []string{}
			flattenPositiveTerms(ast, false, &terms)
			value = strings.Join(terms, " ")
		}
	} else {
		if f := ast.GetFilter(); f != nil {
			value = strings.TrimSpace(f.GetValue())
		} else {
			terms := []string{}
			flattenPositiveTerms(ast, false, &terms)
			value = strings.Join(terms, " ")
		}
	}

	value = strings.TrimSpace(value)
	if value == "" {
		return "", nil, fmt.Errorf("empty query derived from AST")
	}

	params[paramName] = value
	return templateID, params, nil
}

func (s *storageServer) SearchBooks(ctx context.Context, req *libraryv1.SearchRequest) (*libraryv1.SearchResponse, error) {
	templateID, params, err := buildTemplateRequest(req)
	if err != nil {
		return nil, err
	}

	osReqBody := map[string]interface{}{
		"id":     templateID,
		"params": params,
	}

	jsonData, _ := json.Marshal(osReqBody)
	targetURL := fmt.Sprintf("%s/%s/_search/template", s.osBaseURL, s.indexName)

	if s.debug {
		log.Printf("📤 [OS-REQ] URL: %s | BODY: %s", targetURL, string(jsonData))
	}

	resp, err := http.Post(targetURL, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	// Total может быть числом, объектом или отсутствовать
	var osRaw struct {
		Hits struct {
			Total interface{} `json:"total"`
			Hits  []struct {
				Source struct {
					Title   string   `json:"title"`
					Authors []string `json:"authors"`
				} `json:"_source"`
				ID string `json:"_id"`
			} `json:"hits"`
		} `json:"hits"`
	}

	if err := json.Unmarshal(body, &osRaw); err != nil {
		log.Printf("❌ Storage parse error: %v", err)
		return &libraryv1.SearchResponse{Status: "error"}, nil
	}

	var totalValue int32
	switch v := osRaw.Hits.Total.(type) {
	case float64:
		totalValue = int32(v)
	case map[string]interface{}:
		if val, ok := v["value"].(float64); ok {
			totalValue = int32(val)
		}
	}

	res := &libraryv1.SearchResponse{Status: "ok"}
	for _, hit := range osRaw.Hits.Hits {
		res.Books = append(res.Books, &libraryv1.Book{
			Id:      hit.ID,
			Title:   hit.Source.Title,
			Authors: hit.Source.Authors,
		})
	}

	// FALLBACK: если хиты есть, а total 0 или не распарсился
	if totalValue == 0 && len(res.Books) > 0 {
		totalValue = int32(len(res.Books))
	}
	res.Total = totalValue

	if s.debug {
		log.Printf("📥 [OS-RESP] Found: %d books", totalValue)
	}

	return res, nil
}

func main() {
	cfg := config.Get()

	lis, err := net.Listen(cfg.Datamanager.Protocol, cfg.Datamanager.Address())
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	s := grpc.NewServer()
	libraryv1.RegisterStorageServiceServer(s, &storageServer{
		osBaseURL: cfg.OpenSearch.URL,
		indexName: cfg.OpenSearch.IndexName,
		debug:     cfg.OpenSearch.Debug,
	})

	log.Printf("💾 DataManager (Storage) started on %s (%s)", cfg.Datamanager.Address(), cfg.Datamanager.Protocol)
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
