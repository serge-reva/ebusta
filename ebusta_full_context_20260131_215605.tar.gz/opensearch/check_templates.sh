#!/bin/bash

# Настройки (как в твоем конфиге)
OS_HOST="http://cloud-1:9200"

# Список всех ожидаемых шаблонов
TEMPLATES=(
    "fl_mixed_search"       # Дефолтный
    "fl_author_exact"       # Автор (точно)
    "fl_author_fuzzy"       # Автор (нечетко)
    "fl_title_match"        # Название (точно)
    "fl_title_substring"    # Название (подстрока)
    "fl_titles_all"         # Агрегация названий
    "fl_authors_all"        # Агрегация авторов
    "fl_title_prefix"       # Префикс названия
    "fl_names_token_prefix" # Префикс имен
    "fl_id_lookup"          # [NEW] Поиск по ID
    "fl_desc_match"         # [NEW] Поиск по описанию
    "fl_container_lookup"   # [NEW] Поиск по архиву
    "fl_filename_lookup"    # [NEW] Поиск по файлу
    "fl_author_id"          # [NEW] Автор как ID
)

echo "=== Проверка шаблонов OpenSearch ($OS_HOST) ==="
echo "------------------------------------------------"
printf "%-25s | %-10s\n" "TEMPLATE ID" "STATUS"
echo "------------------------------------------------"

ALL_OK=true

for tpl in "${TEMPLATES[@]}"; do
    # Запрашиваем только код ответа (200 = OK, 404 = Missing)
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$OS_HOST/_scripts/$tpl")

    if [ "$HTTP_CODE" == "200" ]; then
        printf "%-25s | \033[0;32m✅ INSTALLED\033[0m\n" "$tpl"
    else
        printf "%-25s | \033[0;31m❌ MISSING ($HTTP_CODE)\033[0m\n" "$tpl"
        ALL_OK=false
    fi
done

echo "------------------------------------------------"
if [ "$ALL_OK" = true ]; then
    echo "🎉 Все шаблоны на месте. Система готова."
else
    echo "⚠️  Внимание: Найдены отсутствующие шаблоны."
    echo "    Запусти команды curl из предыдущего шага для их загрузки."
fi
