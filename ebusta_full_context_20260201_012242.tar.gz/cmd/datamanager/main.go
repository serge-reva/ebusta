package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strconv"

	libraryv1 "ebusta/api/proto/v1"
	"ebusta/internal/config"

	"google.golang.org/grpc"
)

type storageServer struct {
	libraryv1.UnimplementedStorageServiceServer
	osBaseURL string
	indexName string
	debug     bool
}

func normalizeSize(limit int32) int32 {
	if limit <= 0 {
		return 10
	}
	return limit
}

func osBodyFromFilterNode(f *libraryv1.FilterNode, overrideTemplateID string, size, from int32) (map[string]interface{}, bool, error) {
	if f == nil {
		return nil, false, fmt.Errorf("nil filter")
	}

	templateID := overrideTemplateID
	paramName := "query"

	// If caller didn't force template, choose by (field, op)
	if templateID == "" {
		switch f.GetField() {
		case "author":
			paramName = "author"
			if f.GetOperator() == libraryv1.Operator_EQUALS {
				templateID = "fl_author_exact"
			} else {
				templateID = "fl_author_fuzzy"
			}
		case "title":
			paramName = "query"
			if f.GetOperator() == libraryv1.Operator_EQUALS {
				templateID = "fl_title_match"
			} else {
				templateID = "fl_title_substring"
			}
		case "id":
			templateID = "fl_id_lookup"
		case "container":
			templateID = "fl_container_lookup"
		case "filename":
			templateID = "fl_filename_lookup"
		case "desc", "annotation":
			templateID = "fl_desc_match"
		default:
			templateID = "fl_mixed_search"
		}
	} else {
		// Forced template id: choose param name consistently with the old behavior
		switch templateID {
		case "fl_author_exact", "fl_author_fuzzy":
			paramName = "author"
		default:
			paramName = "query"
		}
	}

	body := map[string]interface{}{
		"id": templateID,
		"params": map[string]interface{}{
			paramName: f.GetValue(),
			"from":    from,
			"size":    size,
		},
	}
	return body, true, nil
}

func clauseFromFilterNode(f *libraryv1.FilterNode) (map[string]interface{}, error) {
	if f == nil {
		return nil, fmt.Errorf("nil filter")
	}

	field := f.GetField()
	val := f.GetValue()

	switch field {
	case "author":
		// Same semantics as fl_author_fuzzy
		return map[string]interface{}{
			"match": map[string]interface{}{
				"authors": map[string]interface{}{
					"query":    val,
					"operator": "and",
				},
			},
		}, nil

	case "title":
		// Same semantics as fl_title_substring
		pattern := "*" + val + "*"
		return map[string]interface{}{
			"query_string": map[string]interface{}{
				"query": pattern,
				"fields": []interface{}{
					"title.kw",
					"authors.kw",
				},
			},
		}, nil

	case "id":
		// Same semantics as fl_id_lookup
		return map[string]interface{}{
			"term": map[string]interface{}{
				"_id": val,
			},
		}, nil

	case "year":
		// Strict: if it's not a number, treat as string term
		if y, err := strconv.Atoi(val); err == nil {
			return map[string]interface{}{
				"term": map[string]interface{}{
					"year": y,
				},
			}, nil
		}
		return map[string]interface{}{
			"term": map[string]interface{}{
				"year": val,
			},
		}, nil

	default:
		// any / unknown: same semantics as fl_mixed_search (minus collapse)
		return map[string]interface{}{
			"multi_match": map[string]interface{}{
				"query": val,
				"fields": []interface{}{
					"title^3",
					"authors",
					"annotation",
					"fileInfo.container",
					"fileInfo.filename",
				},
				"type":      "best_fields",
				"operator":  "or",
				"fuzziness": "AUTO",
			},
		}, nil
	}
}

func clauseFromAST(q *libraryv1.SearchQuery) (map[string]interface{}, error) {
	if q == nil {
		return nil, fmt.Errorf("nil ast")
	}

	if f := q.GetFilter(); f != nil {
		return clauseFromFilterNode(f)
	}

	if n := q.GetNegation(); n != nil {
		child, err := clauseFromAST(n.GetNode())
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{
			"bool": map[string]interface{}{
				"must_not": []interface{}{child},
			},
		}, nil
	}

	if l := q.GetLogical(); l != nil {
		var clauses []interface{}
		for _, node := range l.GetNodes() {
			c, err := clauseFromAST(node)
			if err != nil {
				return nil, err
			}
			clauses = append(clauses, c)
		}

		switch l.GetOp() {
		case libraryv1.LogicalOp_AND:
			return map[string]interface{}{
				"bool": map[string]interface{}{
					"must": clauses,
				},
			}, nil
		case libraryv1.LogicalOp_OR:
			return map[string]interface{}{
				"bool": map[string]interface{}{
					"should":               clauses,
					"minimum_should_match": 1,
				},
			}, nil
		case libraryv1.LogicalOp_NOT:
			// Library NOT is a dedicated node in our schema; handle here just in case.
			if len(clauses) != 1 {
				return nil, fmt.Errorf("NOT expects 1 node, got %d", len(clauses))
			}
			return map[string]interface{}{
				"bool": map[string]interface{}{
					"must_not": []interface{}{clauses[0]},
				},
			}, nil
		default:
			return nil, fmt.Errorf("unknown logical op: %v", l.GetOp())
		}
	}

	return nil, fmt.Errorf("ast: empty node")
}

func osBodyFromAST(ast *libraryv1.SearchQuery, overrideTemplateID string, size, from int32) (map[string]interface{}, error) {
	// Use stored templates for the simplest case (single filter).
	if f := ast.GetFilter(); f != nil {
		body, ok, err := osBodyFromFilterNode(f, overrideTemplateID, size, from)
		if err != nil {
			return nil, err
		}
		if ok {
			return body, nil
		}
	}

	clause, err := clauseFromAST(ast)
	if err != nil {
		return nil, err
	}

	// Inline template body (still goes through /_search/template as required).
	return map[string]interface{}{
		"source": map[string]interface{}{
			"from":  from,
			"size":  size,
			"query": clause,
			"_source": []interface{}{
				"title",
				"authors",
				"year",
				"fileInfo.container",
				"fileInfo.filename",
				"annotation",
			},
		},
	}, nil
}

func (s *storageServer) SearchBooks(ctx context.Context, req *libraryv1.SearchRequest) (*libraryv1.SearchResponse, error) {
	size := normalizeSize(req.GetLimit())
	from := req.GetOffset()

	var osReqBody map[string]interface{}
	var err error

	if req.GetAst() != nil {
		// Preferred path: orchestrator passes structured AST.
		osReqBody, err = osBodyFromAST(req.GetAst(), req.GetTemplateId(), size, from)
		if err != nil {
			log.Printf("❌ [AST->OS] build error: %v", err)
			return &libraryv1.SearchResponse{Status: "error"}, nil
		}
	} else {
		// Backward-compatible path (direct StorageService calls).
		templateID := req.GetTemplateId()
		if templateID == "" {
			templateID = "fl_mixed_search"
		}

		paramName := "query"
		switch templateID {
		case "fl_author_exact", "fl_author_fuzzy":
			paramName = "author"
		default:
			paramName = "query"
		}

		osReqBody = map[string]interface{}{
			"id": templateID,
			"params": map[string]interface{}{
				paramName: req.GetQuery(),
				"from":    from,
				"size":    size,
			},
		}
	}

	jsonData, _ := json.Marshal(osReqBody)
	targetURL := fmt.Sprintf("%s/%s/_search/template", s.osBaseURL, s.indexName)
	if s.debug {
		log.Printf("📤 [OS-REQ] URL: %s | BODY: %s", targetURL, string(jsonData))
	}

	resp, err := http.Post(targetURL, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	// Flexible parsing: total can be number, object, or missing
	var osRaw struct {
		Hits struct {
			Total interface{} `json:"total"`
			Hits  []struct {
				Source struct {
					Title   string   `json:"title"`
					Authors []string `json:"authors"`
				} `json:"_source"`
				ID string `json:"_id"`
			} `json:"hits"`
		} `json:"hits"`
	}

	if err := json.Unmarshal(body, &osRaw); err != nil {
		log.Printf("❌ Storage parse error: %v", err)
		return &libraryv1.SearchResponse{Status: "error"}, nil
	}

	var totalValue int32
	switch v := osRaw.Hits.Total.(type) {
	case float64:
		totalValue = int32(v)
	case map[string]interface{}:
		if val, ok := v["value"].(float64); ok {
			totalValue = int32(val)
		}
	}

	res := &libraryv1.SearchResponse{Status: "ok"}
	for _, hit := range osRaw.Hits.Hits {
		res.Books = append(res.Books, &libraryv1.Book{
			Id:      hit.ID,
			Title:   hit.Source.Title,
			Authors: hit.Source.Authors,
		})
	}

	// Fallback: if hits exist but total is missing/0
	if totalValue == 0 && len(res.Books) > 0 {
		totalValue = int32(len(res.Books))
	}
	res.Total = totalValue

	if s.debug {
		log.Printf("📥 [OS-RESP] Found: %d books", totalValue)
	}
	return res, nil
}

func main() {
	cfg := config.Get()

	osBaseURL := cfg.OpenSearch.URL
	indexName := cfg.OpenSearch.IndexName
	debug := cfg.OpenSearch.Debug

	protocol := cfg.Datamanager.Protocol
	addr := cfg.Datamanager.Address()

	lis, err := net.Listen(protocol, addr)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	s := grpc.NewServer()
	libraryv1.RegisterStorageServiceServer(s, &storageServer{
		osBaseURL: osBaseURL,
		indexName: indexName,
		debug:     debug,
	})

	log.Printf("💾 DataManager (Storage) started on %s (%s)", addr, protocol)
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
