package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"net/http"
	"sync/atomic"

	dsl "ebusta/api/gen/dsl"
	libraryv1 "ebusta/api/proto/v1"
	"ebusta/internal/config"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var orchestratorRequestsTotal uint64

type orchestratorServer struct {
	libraryv1.UnimplementedOrchestratorServiceServer
	dslClient     dsl.MessageConverterClient
	storageClient libraryv1.StorageServiceClient
}

func mapDSLToAST(in *dsl.SearchQuery) (*libraryv1.SearchQuery, error) {
	if in == nil {
		return nil, fmt.Errorf("dsl: nil query")
	}

	if f := in.GetFilter(); f != nil {
		var op libraryv1.Operator
		switch f.GetOperator() {
		case 0:
			op = libraryv1.Operator_EQUALS
		case 1:
			op = libraryv1.Operator_CONTAINS
		case 2:
			op = libraryv1.Operator_REGEX
		default:
			return nil, fmt.Errorf("dsl: unknown operator %d", f.GetOperator())
		}

		return &libraryv1.SearchQuery{
			Node: &libraryv1.SearchQuery_Filter{
				Filter: &libraryv1.FilterNode{
					Field:    f.GetField(),
					Value:    f.GetValue(),
					Operator: op,
				},
			},
		}, nil
	}

	if l := in.GetLogical(); l != nil {
		// DSL logical op: 1=AND, 2=OR, 3=NOT (unary)
		if l.GetOp() == 3 {
			if len(l.GetNodes()) != 1 {
				return nil, fmt.Errorf("dsl: NOT expects 1 node, got %d", len(l.GetNodes()))
			}
			child, err := mapDSLToAST(l.GetNodes()[0])
			if err != nil {
				return nil, err
			}
			return &libraryv1.SearchQuery{
				Node: &libraryv1.SearchQuery_Negation{
					Negation: &libraryv1.NotNode{Node: child},
				},
			}, nil
		}

		var op libraryv1.LogicalOp
		switch l.GetOp() {
		case 1:
			op = libraryv1.LogicalOp_AND
		case 2:
			op = libraryv1.LogicalOp_OR
		default:
			return nil, fmt.Errorf("dsl: unknown logical op %d", l.GetOp())
		}

		out := &libraryv1.LogicalNode{Op: op}
		for _, n := range l.GetNodes() {
			child, err := mapDSLToAST(n)
			if err != nil {
				return nil, err
			}
			out.Nodes = append(out.Nodes, child)
		}

		return &libraryv1.SearchQuery{
			Node: &libraryv1.SearchQuery_Logical{Logical: out},
		}, nil
	}

	return nil, fmt.Errorf("dsl: empty query (no filter/logical)")
}

func (s *orchestratorServer) Search(ctx context.Context, req *libraryv1.SearchRequest) (*libraryv1.SearchResponse, error) {
	atomic.AddUint64(&orchestratorRequestsTotal, 1)
	log.Printf("🎼 Orchestrator received: %s", req.Query)

	log.Printf("🎼 Orchestrator -> DSL-Converter")
	dslResp, err := s.dslClient.Convert(ctx, &dsl.ConvertRequest{
		RawQuery: req.Query,
	})
	if err != nil {
		log.Printf("❌ DSL Error: %v", err)
		return nil, err
	}

	log.Printf("🎼 DSL CanonicalForm: %s", dslResp.GetCanonicalForm())

	ast, err := mapDSLToAST(dslResp)
	if err != nil {
		log.Printf("❌ DSL->AST map error: %v", err)
		return nil, err
	}

	// Orchestrator owns the DTO: raw query stays raw; structured AST goes separately.
	searchReq := &libraryv1.SearchRequest{
		Query:      req.Query,
		Ast:        ast,
		TemplateId: req.TemplateId,
		Limit:      req.Limit,
		Offset:     req.Offset,
		TraceId:    req.TraceId,
	}

	log.Printf("🎼 Orchestrator -> Storage (DataManager)")
	return s.storageClient.SearchBooks(ctx, searchReq)
}

func main() {
	cfg := config.Get()

	orchAddr := cfg.Orchestrator.Address()
	log.Printf("=== [ORCHESTRATOR] Starting on %s ===", orchAddr)

	dslAddr := cfg.LispConverter.Address()
	storageAddr := cfg.Datamanager.Address()

	dslConn, err := grpc.Dial(dslAddr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("failed to connect to dsl: %v", err)
	}

	storageConn, err := grpc.Dial(storageAddr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("failed to connect to storage: %v", err)
	}

	lis, err := net.Listen(cfg.Orchestrator.Protocol, orchAddr)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	s := grpc.NewServer()
	libraryv1.RegisterOrchestratorServiceServer(s, &orchestratorServer{
		dslClient:     dsl.NewMessageConverterClient(dslConn),
		storageClient: libraryv1.NewStorageServiceClient(storageConn),
	})

	log.Println("🎼 Orchestrator service registered")

	// Prometheus text endpoint on dedicated HTTP port
	go func() {
		mux := http.NewServeMux()
		mux.HandleFunc("/metrics", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
			fmt.Fprintln(w, "# HELP orchestrator_up 1 if orchestrator process is running")
			fmt.Fprintln(w, "# TYPE orchestrator_up gauge")
			fmt.Fprintln(w, "orchestrator_up 1")
			fmt.Fprintln(w, "# HELP orchestrator_requests_total Total Search requests handled")
			fmt.Fprintln(w, "# TYPE orchestrator_requests_total counter")
			fmt.Fprintf(w, "orchestrator_requests_total %d\n", atomic.LoadUint64(&orchestratorRequestsTotal))
		})
		addr := fmt.Sprintf(":%d", cfg.Metrics.Port)
		log.Printf("📈 Metrics listening on %s/metrics", addr)
		if err := http.ListenAndServe(addr, mux); err != nil && err != http.ErrServerClosed {
			log.Printf("metrics serve error: %v", err)
		}
	}()

	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
