#!/bin/bash
set -e

echo "🛠 1. Синхронизация имен параметров в тестах (q -> query)..."
# Исправляем параметры в smoke_full.sh для прямых вызовов curl
if [ -f tests/smoke_full.sh ]; then
    sed -i 's/"q":/"query":/g' tests/smoke_full.sh
    # Также убедимся, что там cloud-1 (на всякий случай)
    sed -i 's/192.168.1.179/cloud-1/g' tests/smoke_full.sh
fi

echo "🚀 2. Перезапуск системы для чистоты эксперимента..."
make stop
make run

echo "⏳ Ожидание (5 сек)..."
sleep 5

echo "🧪 3. Финальный прогон smoke..."
make smoke

echo "🏁 Все тесты (кроме специфических ограничений процессора) должны пройти."
